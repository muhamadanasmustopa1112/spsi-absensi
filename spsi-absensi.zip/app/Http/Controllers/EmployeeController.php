<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Http;
use Stevebauman\Location\Facades\Location;

use Illuminate\Http\Request;

class EmployeeController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }

    public function reverseGeocode($latitude, $longitude)
    {
        // Nominatim API URL
        $url = "https://nominatim.openstreetmap.org/reverse?format=json&lat={$latitude}&lon={$longitude}&addressdetails=1";

        // Make the API request
        $response = Http::get($url);

        // Parse the response JSON
        $data = $response->json();

        // Check if address is available in the response
        if (isset($data['address'])) {
            // Return the display name (full address) or specific address components
            return $data['display_name'];
        } else {
            return 'Address not found';
        }
    }

    public function showLocation(Request $request)
    {
        // Example coordinates (you can get them from a request or another source)
        // $latitude = -6.9376274; 
        // $longitude = 107.6333816;
        $ipAddress = $request->ip();


        // // Get the address using the reverse geocode method
        // $address = $this->reverseGeocode($latitude, $longitude);
        $position = Location::get($ipAddress);

        return response()->json([
            'address' => $position,
        ]);

   
        
    }
    
}
